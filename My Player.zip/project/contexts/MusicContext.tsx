import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import { Audio } from 'expo-av';
import * as MediaLibrary from 'expo-media-library';
import { Platform } from 'react-native';

interface Track {
  id: string;
  title: string;
  artist: string;
  album?: string;
  duration?: number;
  uri: string;
  artwork?: string;
}

interface Playlist {
  id: string;
  name: string;
  trackCount: number;
  colors?: string[];
}

interface MusicContextType {
  currentTrack: Track | null;
  isPlaying: boolean;
  position: number;
  duration: number;
  allTracks: Track[];
  recentlyPlayed: Track[];
  recommendedTracks: Track[];
  playlists: Playlist[];
  favorites: Track[];
  isLoading: boolean;
  permissionStatus: string;
  playTrack: (track: Track) => void;
  playPause: () => void;
  nextTrack: () => void;
  previousTrack: () => void;
  seekTo: (position: number) => void;
  loadMusicLibrary: () => void;
  requestPermissions: () => void;
}

const MusicContext = createContext<MusicContextType | undefined>(undefined);

export const useMusicContext = () => {
  const context = useContext(MusicContext);
  if (!context) {
    throw new Error('useMusicContext must be used within a MusicProvider');
  }
  return context;
};

export const MusicProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [position, setPosition] = useState(0);
  const [duration, setDuration] = useState(0);
  const [sound, setSound] = useState<Audio.Sound | null>(null);
  const [allTracks, setAllTracks] = useState<Track[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [permissionStatus, setPermissionStatus] = useState('unknown');
  
  // Use refs to prevent multiple simultaneous operations and track state
  const isLoadingTrack = useRef(false);
  const positionUpdateInterval = useRef<NodeJS.Timeout | null>(null);
  const currentSoundRef = useRef<Audio.Sound | null>(null);
  const statusUpdateCallback = useRef<((status: any) => void) | null>(null);

  // Mock data for web platform fallback
  const mockTracks: Track[] = [
    {
      id: '1',
      title: 'Sunset Dreams',
      artist: 'Ocean Waves',
      album: 'Coastal Vibes',
      duration: 240000,
      uri: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav',
      artwork: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg',
    },
    {
      id: '2',
      title: 'City Lights',
      artist: 'Urban Echo',
      album: 'Metropolitan',
      duration: 195000,
      uri: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav',
      artwork: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg',
    },
    {
      id: '3',
      title: 'Mountain High',
      artist: 'Nature Sounds',
      album: 'Wilderness',
      duration: 280000,
      uri: 'https://www.soundjay.com/misc/sounds/bell-ringing-05.wav',
      artwork: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg',
    },
  ];

  const mockPlaylists: Playlist[] = [
    {
      id: '1',
      name: 'My Favorites',
      trackCount: 25,
      colors: ['#ff6b6b', '#ee5a52'],
    },
    {
      id: '2',
      name: 'Chill Vibes',
      trackCount: 18,
      colors: ['#4ecdc4', '#44a08d'],
    },
    {
      id: '3',
      name: 'Workout Mix',
      trackCount: 32,
      colors: ['#667eea', '#764ba2'],
    },
  ];

  useEffect(() => {
    // Initialize audio mode
    Audio.setAudioModeAsync({
      allowsRecordingIOS: false,
      staysActiveInBackground: true,
      playsInSilentModeIOS: true,
      shouldDuckAndroid: true,
      playThroughEarpieceAndroid: false,
    });

    // Check permissions and load music library on mount
    checkPermissionsAndLoadMusic();

    return () => {
      // Cleanup
      cleanupAudio();
      if (positionUpdateInterval.current) {
        clearInterval(positionUpdateInterval.current);
      }
    };
  }, []);

  // Cleanup function for audio resources
  const cleanupAudio = async () => {
    try {
      // Clear any existing status update callback
      if (statusUpdateCallback.current && currentSoundRef.current) {
        currentSoundRef.current.setOnPlaybackStatusUpdate(null);
        statusUpdateCallback.current = null;
      }

      // Unload current sound
      if (currentSoundRef.current) {
        await currentSoundRef.current.unloadAsync();
        currentSoundRef.current = null;
      }

      // Unload any other sound instances
      if (sound && sound !== currentSoundRef.current) {
        await sound.unloadAsync();
      }

      // Clear position update interval
      if (positionUpdateInterval.current) {
        clearInterval(positionUpdateInterval.current);
        positionUpdateInterval.current = null;
      }
    } catch (error) {
      console.error('Error cleaning up audio:', error);
    }
  };

  // Start position tracking when playing
  useEffect(() => {
    if (isPlaying && currentSoundRef.current) {
      positionUpdateInterval.current = setInterval(async () => {
        try {
          const status = await currentSoundRef.current?.getStatusAsync();
          if (status?.isLoaded && status.isPlaying && !status.isBuffering) {
            setPosition(status.positionMillis || 0);
          }
        } catch (error) {
          console.error('Error getting position:', error);
        }
      }, 1000);
    } else {
      if (positionUpdateInterval.current) {
        clearInterval(positionUpdateInterval.current);
        positionUpdateInterval.current = null;
      }
    }

    return () => {
      if (positionUpdateInterval.current) {
        clearInterval(positionUpdateInterval.current);
      }
    };
  }, [isPlaying]);

  const checkPermissionsAndLoadMusic = async () => {
    if (Platform.OS === 'web') {
      // Use mock data for web
      setAllTracks(mockTracks);
      setCurrentTrack(mockTracks[0]);
      setPermissionStatus('granted');
      return;
    }

    try {
      const { status } = await MediaLibrary.getPermissionsAsync();
      setPermissionStatus(status);
      
      if (status === 'granted') {
        await loadMusicLibrary();
      } else {
        // Use mock data if no permission
        setAllTracks(mockTracks);
        setCurrentTrack(mockTracks[0]);
      }
    } catch (error) {
      console.error('Error checking permissions:', error);
      setAllTracks(mockTracks);
      setCurrentTrack(mockTracks[0]);
      setPermissionStatus('denied');
    }
  };

  const requestPermissions = async () => {
    if (Platform.OS === 'web') {
      setPermissionStatus('granted');
      return;
    }

    try {
      const { status } = await MediaLibrary.requestPermissionsAsync();
      setPermissionStatus(status);
      
      if (status === 'granted') {
        await loadMusicLibrary();
      }
    } catch (error) {
      console.error('Error requesting permissions:', error);
      setPermissionStatus('denied');
    }
  };

  const loadMusicLibrary = async () => {
    if (Platform.OS === 'web') {
      setAllTracks(mockTracks);
      return;
    }

    setIsLoading(true);
    
    try {
      const { status } = await MediaLibrary.getPermissionsAsync();
      
      if (status !== 'granted') {
        console.log('Media library permission not granted');
        setAllTracks(mockTracks);
        setIsLoading(false);
        return;
      }

      // Get audio assets from device
      const media = await MediaLibrary.getAssetsAsync({
        mediaType: 'audio',
        first: 1000, // Load up to 1000 tracks
        sortBy: [MediaLibrary.SortBy.creationTime],
      });
      
      console.log(`Found ${media.assets.length} audio files`);

      if (media.assets.length === 0) {
        console.log('No audio files found, using mock data');
        setAllTracks(mockTracks);
        setCurrentTrack(mockTracks[0]);
        setIsLoading(false);
        return;
      }

      // Convert MediaLibrary assets to Track objects
      const tracks: Track[] = await Promise.all(
        media.assets.map(async (asset, index) => {
          // Extract metadata
          const assetInfo = await MediaLibrary.getAssetInfoAsync(asset);
          
          // Clean up filename to get title
          let title = asset.filename.replace(/\.[^/.]+$/, ''); // Remove extension
          title = title.replace(/^\d+[\s\-\.]*/, ''); // Remove track numbers
          
          // Try to extract artist from filename or use default
          let artist = 'Unknown Artist';
          let album = 'Unknown Album';
          
          // Simple parsing for common filename formats
          if (title.includes(' - ')) {
            const parts = title.split(' - ');
            if (parts.length >= 2) {
              artist = parts[0].trim();
              title = parts[1].trim();
            }
          }

          return {
            id: asset.id,
            title: title || `Track ${index + 1}`,
            artist: artist,
            album: album,
            duration: asset.duration * 1000, // Convert to milliseconds
            uri: asset.uri, // Use the original URI directly without modification
            artwork: `https://images.pexels.com/photos/${1763075 + (index % 10)}/pexels-photo-${1763075 + (index % 10)}.jpeg?auto=compress&cs=tinysrgb&w=300`,
          };
        })
      );
      
      console.log(`Processed ${tracks.length} tracks`);
      setAllTracks(tracks);
      
      // Set first track as current if no track is selected
      if (!currentTrack && tracks.length > 0) {
        setCurrentTrack(tracks[0]);
      }
      
    } catch (error) {
      console.error('Error loading music library:', error);
      // Fallback to mock data on error
      setAllTracks(mockTracks);
      setCurrentTrack(mockTracks[0]);
    } finally {
      setIsLoading(false);
    }
  };

  const playTrack = async (track: Track) => {
    // Prevent multiple simultaneous track loading
    if (isLoadingTrack.current) {
      console.log('Already loading a track, ignoring request');
      return;
    }
    
    isLoadingTrack.current = true;
    
    try {
      console.log('Playing track:', track.title, 'URI:', track.uri);

      // Stop and cleanup current sound first
      await cleanupAudio();
      
      // Reset all state
      setSound(null);
      setIsPlaying(false);
      setPosition(0);
      setDuration(0);

      // Small delay to ensure cleanup is complete
      await new Promise(resolve => setTimeout(resolve, 150));

      // Create and load new sound
      const { sound: newSound } = await Audio.Sound.createAsync(
        { uri: track.uri },
        { 
          shouldPlay: false, // Don't auto-play initially
          isLooping: false,
          volume: 1.0,
        }
      );

      // Update refs and state
      currentSoundRef.current = newSound;
      setSound(newSound);
      setCurrentTrack(track);
      
      // Update current index
      const index = allTracks.findIndex(t => t.id === track.id);
      if (index !== -1) {
        setCurrentIndex(index);
      }

      // Set up playback status listener with proper cleanup
      const statusCallback = (status: any) => {
        // Only process status updates for the current sound
        if (currentSoundRef.current !== newSound) {
          return;
        }

        if (status.isLoaded) {
          setDuration(status.durationMillis || 0);
          setIsPlaying(status.isPlaying);
          
          // Auto-play next track when current track finishes
          if (status.didJustFinish) {
            nextTrack();
          }
        } else if (status.error) {
          console.error('Playback error:', status.error);
          setIsPlaying(false);
        }
      };

      statusUpdateCallback.current = statusCallback;
      newSound.setOnPlaybackStatusUpdate(statusCallback);

      // Start playing after setup is complete
      await newSound.playAsync();
      
    } catch (error) {
      console.error('Error playing track:', error);
      setIsPlaying(false);
    } finally {
      isLoadingTrack.current = false;
    }
  };

  const playPause = async () => {
    if (!currentSoundRef.current) {
      // If no sound loaded, play current track
      if (currentTrack) {
        await playTrack(currentTrack);
      }
      return;
    }

    try {
      const status = await currentSoundRef.current.getStatusAsync();
      if (status.isLoaded) {
        if (status.isPlaying) {
          await currentSoundRef.current.pauseAsync();
        } else {
          await currentSoundRef.current.playAsync();
        }
      }
    } catch (error) {
      console.error('Error toggling playback:', error);
    }
  };

  const nextTrack = async () => {
    if (allTracks.length === 0 || isLoadingTrack.current) return;
    
    const nextIndex = (currentIndex + 1) % allTracks.length;
    await playTrack(allTracks[nextIndex]);
  };

  const previousTrack = async () => {
    if (allTracks.length === 0 || isLoadingTrack.current) return;
    
    const prevIndex = currentIndex === 0 ? allTracks.length - 1 : currentIndex - 1;
    await playTrack(allTracks[prevIndex]);
  };

  const seekTo = async (positionMillis: number) => {
    if (currentSoundRef.current) {
      try {
        await currentSoundRef.current.setPositionAsync(positionMillis);
        setPosition(positionMillis);
      } catch (error) {
        console.error('Error seeking:', error);
      }
    }
  };

  const value: MusicContextType = {
    currentTrack,
    isPlaying,
    position,
    duration,
    allTracks,
    recentlyPlayed: allTracks.slice(0, 5), // Show first 5 tracks as recently played
    recommendedTracks: allTracks.slice(5, 10), // Show next 5 as recommended
    playlists: mockPlaylists,
    favorites: allTracks.slice(0, 3), // Show first 3 as favorites
    isLoading,
    permissionStatus,
    playTrack,
    playPause,
    nextTrack,
    previousTrack,
    seekTo,
    loadMusicLibrary,
    requestPermissions,
  };

  return (
    <MusicContext.Provider value={value}>
      {children}
    </MusicContext.Provider>
  );
};
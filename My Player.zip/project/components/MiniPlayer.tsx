import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Play, Pause, SkipForward } from 'lucide-react-native';
import { useMusicContext } from '@/contexts/MusicContext';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const { width } = Dimensions.get('window');

export const MiniPlayer: React.FC = () => {
  const { currentTrack, isPlaying, playPause, nextTrack, position, duration } = useMusicContext();
  const insets = useSafeAreaInsets();
  const progress = duration > 0 ? position / duration : 0;

  if (!currentTrack) return null;

  const handlePlayerPress = () => {
    router.push('/player');
  };

  return (
    <TouchableOpacity 
      style={[styles.container, { bottom: insets.bottom }]}
      onPress={handlePlayerPress}
      activeOpacity={0.9}
    >
      <BlurView intensity={95} style={styles.blur}>
        <LinearGradient
          colors={['rgba(15, 15, 35, 0.95)', 'rgba(26, 26, 46, 0.95)']}
          style={styles.gradient}
        >
          {/* Progress Bar */}
          <View style={styles.progressContainer}>
            <View style={styles.progressBar}>
              <LinearGradient
                colors={['#667eea', '#764ba2']}
                style={[styles.progressFill, { width: `${progress * 100}%` }]}
              />
            </View>
          </View>

          {/* Player Content */}
          <View style={styles.content}>
            <View style={styles.trackInfo}>
              <Image 
                source={{ uri: currentTrack.artwork || 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=200' }}
                style={styles.artwork}
              />
              <View style={styles.textInfo}>
                <Text style={styles.title} numberOfLines={1}>
                  {currentTrack.title}
                </Text>
                <Text style={styles.artist} numberOfLines={1}>
                  {currentTrack.artist}
                </Text>
              </View>
            </View>

            <View style={styles.controls}>
              <TouchableOpacity 
                style={styles.controlButton}
                onPress={(e) => {
                  e.stopPropagation();
                  playPause();
                }}
              >
                {isPlaying ? (
                  <Pause size={20} color="#ffffff" fill="#ffffff" />
                ) : (
                  <Play size={20} color="#ffffff" fill="#ffffff" />
                )}
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.controlButton}
                onPress={(e) => {
                  e.stopPropagation();
                  nextTrack();
                }}
              >
                <SkipForward size={20} color="#ffffff" strokeWidth={2} />
              </TouchableOpacity>
            </View>
          </View>
        </LinearGradient>
      </BlurView>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 12,
    right: 12,
    height: 64,
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 8,
  },
  blur: {
    flex: 1,
  },
  gradient: {
    flex: 1,
  },
  progressContainer: {
    height: 2,
  },
  progressBar: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
  },
  progressFill: {
    height: '100%',
  },
  content: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  trackInfo: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  artwork: {
    width: 44,
    height: 44,
    borderRadius: 8,
  },
  textInfo: {
    flex: 1,
  },
  title: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 14,
    color: '#ffffff',
    marginBottom: 2,
  },
  artist: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.7)',
  },
  controls: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  controlButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
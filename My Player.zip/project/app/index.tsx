import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  TextInput,
  FlatList,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Search, Play, Music, RefreshCw } from 'lucide-react-native';
import { useMusicContext } from '@/contexts/MusicContext';
import { MiniPlayer } from '@/components/MiniPlayer';
import { SafeAreaView } from 'react-native-safe-area-context';

const { width, height } = Dimensions.get('window');

export default function HomeScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredTracks, setFilteredTracks] = useState([]);
  
  const { 
    allTracks,
    playTrack,
    permissionStatus,
    requestPermissions,
    loadMusicLibrary,
    isLoading
  } = useMusicContext();

  useEffect(() => {
    if (searchQuery.trim()) {
      const results = allTracks.filter(track =>
        track.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        track.artist.toLowerCase().includes(searchQuery.toLowerCase()) ||
        track.album?.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredTracks(results);
    } else {
      setFilteredTracks(allTracks);
    }
  }, [searchQuery, allTracks]);

  const handleTrackPress = (track) => {
    playTrack(track);
  };

  const renderPermissionPrompt = () => (
    <View style={styles.permissionPrompt}>
      <LinearGradient
        colors={['#667eea', '#764ba2']}
        style={styles.permissionGradient}
      >
        <Music size={width * 0.15} color="#ffffff" strokeWidth={1.5} />
        <Text style={styles.permissionTitle}>Welcome to My Player</Text>
        <Text style={styles.permissionText}>
          Grant permission to access your music library and start listening to your favorite songs.
        </Text>
        <TouchableOpacity 
          style={styles.permissionButton}
          onPress={requestPermissions}
        >
          <LinearGradient
            colors={['#f093fb', '#f5576c']}
            style={styles.permissionButtonGradient}
          >
            <Text style={styles.permissionButtonText}>Get Started</Text>
          </LinearGradient>
        </TouchableOpacity>
      </LinearGradient>
    </View>
  );

  const renderLoadingState = () => (
    <View style={styles.loadingContainer}>
      <ActivityIndicator size="large" color="#667eea" />
      <Text style={styles.loadingText}>Loading your music library...</Text>
    </View>
  );

  const renderEmptyState = () => (
    <View style={styles.emptyContainer}>
      <View style={styles.emptyIcon}>
        <Music size={width * 0.12} color="rgba(255, 255, 255, 0.3)" strokeWidth={1.5} />
      </View>
      <Text style={styles.emptyTitle}>No Music Found</Text>
      <Text style={styles.emptyText}>
        No audio files were found on your device. Make sure you have music files stored locally.
      </Text>
      <TouchableOpacity 
        style={styles.refreshButton}
        onPress={loadMusicLibrary}
      >
        <RefreshCw size={20} color="#ffffff" strokeWidth={2} />
        <Text style={styles.refreshButtonText}>Refresh Library</Text>
      </TouchableOpacity>
    </View>
  );

  const renderTrackItem = ({ item, index }) => (
    <TouchableOpacity 
      style={styles.trackItem}
      onPress={() => handleTrackPress(item)}
    >
      <View style={styles.trackItemLeft}>
        <Image 
          source={{ uri: item.artwork || `https://images.pexels.com/photos/${1763075 + (index % 10)}/pexels-photo-${1763075 + (index % 10)}.jpeg?auto=compress&cs=tinysrgb&w=200` }}
          style={styles.trackItemImage}
        />
        <View style={styles.trackItemInfo}>
          <Text style={styles.trackItemTitle} numberOfLines={1}>
            {item.title}
          </Text>
          <Text style={styles.trackItemArtist} numberOfLines={1}>
            {item.artist}
          </Text>
          {item.duration && (
            <Text style={styles.trackItemDuration}>
              {Math.floor(item.duration / 60000)}:{String(Math.floor((item.duration % 60000) / 1000)).padStart(2, '0')}
            </Text>
          )}
        </View>
      </View>
      <TouchableOpacity style={styles.trackPlayButton}>
        <Play size={16} color="#ffffff" fill="#ffffff" />
      </TouchableOpacity>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#0f0f23', '#1a1a2e', '#16213e']}
        style={StyleSheet.absoluteFill}
      />
      
      <SafeAreaView style={styles.safeArea}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>My Player</Text>
          <TouchableOpacity 
            style={styles.refreshHeaderButton}
            onPress={loadMusicLibrary}
          >
            <RefreshCw size={width * 0.06} color="#ffffff" strokeWidth={2} />
          </TouchableOpacity>
        </View>

        {permissionStatus !== 'granted' ? (
          renderPermissionPrompt()
        ) : isLoading ? (
          renderLoadingState()
        ) : (
          <>
            {/* Search Bar */}
            <View style={styles.searchContainer}>
              <View style={styles.searchBar}>
                <Search size={20} color="rgba(255, 255, 255, 0.6)" strokeWidth={2} />
                <TextInput
                  style={styles.searchInput}
                  placeholder="Search your music..."
                  placeholderTextColor="rgba(255, 255, 255, 0.5)"
                  value={searchQuery}
                  onChangeText={setSearchQuery}
                />
              </View>
            </View>

            {/* Music Library */}
            <View style={styles.content}>
              {filteredTracks.length > 0 ? (
                <>
                  <View style={styles.statsContainer}>
                    <Text style={styles.statsText}>
                      {filteredTracks.length} song{filteredTracks.length !== 1 ? 's' : ''} 
                      {searchQuery ? ' found' : ' in your library'}
                    </Text>
                  </View>
                  
                  <FlatList
                    data={filteredTracks}
                    renderItem={renderTrackItem}
                    keyExtractor={(item, index) => item.id || index.toString()}
                    showsVerticalScrollIndicator={false}
                    contentContainerStyle={styles.listContent}
                  />
                </>
              ) : searchQuery ? (
                <View style={styles.noResultsContainer}>
                  <View style={styles.noResultsIcon}>
                    <Search size={width * 0.12} color="rgba(255, 255, 255, 0.3)" strokeWidth={1.5} />
                  </View>
                  <Text style={styles.noResultsTitle}>No results found</Text>
                  <Text style={styles.noResultsText}>
                    Try searching with different keywords or check your spelling.
                  </Text>
                </View>
              ) : (
                renderEmptyState()
              )}
            </View>
          </>
        )}
      </SafeAreaView>

      <MiniPlayer />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f0f23',
  },
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: width * 0.06,
    paddingTop: height * 0.025,
    paddingBottom: height * 0.025,
  },
  title: {
    fontFamily: 'Inter-Bold',
    fontSize: width * 0.08,
    color: '#ffffff',
    letterSpacing: -0.5,
  },
  refreshHeaderButton: {
    width: width * 0.11,
    height: width * 0.11,
    borderRadius: width * 0.055,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  permissionPrompt: {
    flex: 1,
    margin: width * 0.06,
    borderRadius: width * 0.06,
    overflow: 'hidden',
    minHeight: height * 0.5,
  },
  permissionGradient: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: width * 0.1,
  },
  permissionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: width * 0.07,
    color: '#ffffff',
    marginTop: height * 0.03,
    marginBottom: height * 0.02,
    textAlign: 'center',
  },
  permissionText: {
    fontFamily: 'Inter-Regular',
    fontSize: width * 0.04,
    color: 'rgba(255, 255, 255, 0.8)',
    textAlign: 'center',
    marginBottom: height * 0.04,
    lineHeight: width * 0.06,
  },
  permissionButton: {
    borderRadius: width * 0.06,
    overflow: 'hidden',
  },
  permissionButtonGradient: {
    paddingHorizontal: width * 0.08,
    paddingVertical: height * 0.02,
  },
  permissionButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: width * 0.04,
    color: '#ffffff',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: width * 0.1,
  },
  loadingText: {
    fontFamily: 'Inter-Regular',
    fontSize: width * 0.04,
    color: 'rgba(255, 255, 255, 0.7)',
    marginTop: height * 0.025,
    textAlign: 'center',
  },
  searchContainer: {
    paddingHorizontal: width * 0.06,
    marginBottom: height * 0.03,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: width * 0.03,
    paddingHorizontal: width * 0.04,
    paddingVertical: height * 0.018,
    gap: width * 0.03,
  },
  searchInput: {
    flex: 1,
    fontFamily: 'Inter-Regular',
    fontSize: width * 0.04,
    color: '#ffffff',
  },
  content: {
    flex: 1,
  },
  statsContainer: {
    paddingHorizontal: width * 0.06,
    marginBottom: height * 0.02,
  },
  statsText: {
    fontFamily: 'Inter-Medium',
    fontSize: width * 0.035,
    color: 'rgba(255, 255, 255, 0.7)',
  },
  listContent: {
    paddingBottom: height * 0.12,
  },
  trackItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: width * 0.06,
    paddingVertical: height * 0.015,
  },
  trackItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: width * 0.03,
  },
  trackItemImage: {
    width: width * 0.14,
    height: width * 0.14,
    borderRadius: width * 0.02,
  },
  trackItemInfo: {
    flex: 1,
  },
  trackItemTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: width * 0.04,
    color: '#ffffff',
    marginBottom: height * 0.005,
  },
  trackItemArtist: {
    fontFamily: 'Inter-Regular',
    fontSize: width * 0.035,
    color: 'rgba(255, 255, 255, 0.7)',
    marginBottom: height * 0.003,
  },
  trackItemDuration: {
    fontFamily: 'Inter-Regular',
    fontSize: width * 0.03,
    color: 'rgba(255, 255, 255, 0.5)',
  },
  trackPlayButton: {
    width: width * 0.1,
    height: width * 0.1,
    borderRadius: width * 0.05,
    backgroundColor: 'rgba(102, 126, 234, 0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: width * 0.1,
  },
  emptyIcon: {
    marginBottom: height * 0.03,
  },
  emptyTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: width * 0.05,
    color: '#ffffff',
    marginBottom: height * 0.015,
    textAlign: 'center',
  },
  emptyText: {
    fontFamily: 'Inter-Regular',
    fontSize: width * 0.04,
    color: 'rgba(255, 255, 255, 0.6)',
    textAlign: 'center',
    marginBottom: height * 0.04,
    lineHeight: width * 0.06,
  },
  refreshButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#667eea',
    paddingHorizontal: width * 0.06,
    paddingVertical: height * 0.015,
    borderRadius: width * 0.06,
    gap: width * 0.02,
  },
  refreshButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: width * 0.035,
    color: '#ffffff',
  },
  noResultsContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: width * 0.1,
    minHeight: height * 0.4,
  },
  noResultsIcon: {
    marginBottom: height * 0.03,
  },
  noResultsTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: width * 0.05,
    color: '#ffffff',
    marginBottom: height * 0.015,
    textAlign: 'center',
  },
  noResultsText: {
    fontFamily: 'Inter-Regular',
    fontSize: width * 0.04,
    color: 'rgba(255, 255, 255, 0.6)',
    textAlign: 'center',
    lineHeight: width * 0.06,
  },
});
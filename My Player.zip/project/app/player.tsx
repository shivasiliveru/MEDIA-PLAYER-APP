import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Dimensions,
  StatusBar,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { ChevronDown, MoveHorizontal as MoreHorizontal, Heart, Play, Pause, SkipForward, SkipBack, Shuffle, Repeat, Volume2, List } from 'lucide-react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useMusicContext } from '@/contexts/MusicContext';
import { router } from 'expo-router';
import Slider from '@react-native-community/slider';

const { width, height } = Dimensions.get('window');

export default function PlayerScreen() {
  const { 
    currentTrack, 
    isPlaying, 
    playPause, 
    nextTrack, 
    previousTrack,
    position,
    duration,
    seekTo
  } = useMusicContext();

  const [isLiked, setIsLiked] = useState(false);
  const [isShuffled, setIsShuffled] = useState(false);
  const [repeatMode, setRepeatMode] = useState(0); // 0: off, 1: all, 2: one
  const [isSeeking, setIsSeeking] = useState(false);
  const [seekPosition, setSeekPosition] = useState(0);

  // Animation values
  const [artworkScale] = useState(new Animated.Value(1));
  const [artworkRotation] = useState(new Animated.Value(0));

  useEffect(() => {
    // Animate artwork when playing
    if (isPlaying) {
      // Scale animation
      Animated.loop(
        Animated.sequence([
          Animated.timing(artworkScale, {
            toValue: 1.02,
            duration: 3000,
            useNativeDriver: true,
          }),
          Animated.timing(artworkScale, {
            toValue: 1,
            duration: 3000,
            useNativeDriver: true,
          }),
        ])
      ).start();

      // Rotation animation
      Animated.loop(
        Animated.timing(artworkRotation, {
          toValue: 1,
          duration: 30000,
          useNativeDriver: true,
        })
      ).start();
    } else {
      artworkScale.stopAnimation();
      artworkRotation.stopAnimation();
    }
  }, [isPlaying]);

  const formatTime = (milliseconds: number) => {
    const minutes = Math.floor(milliseconds / 60000);
    const seconds = Math.floor((milliseconds % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const handleSeekStart = () => {
    setIsSeeking(true);
  };

  const handleSeekChange = (value: number) => {
    const newPosition = value * duration;
    setSeekPosition(newPosition);
  };

  const handleSeekComplete = (value: number) => {
    const newPosition = value * duration;
    seekTo(newPosition);
    setIsSeeking(false);
  };

  const toggleRepeat = () => {
    setRepeatMode((prev) => (prev + 1) % 3);
  };

  const rotateInterpolate = artworkRotation.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  const currentPosition = isSeeking ? seekPosition : position;
  const progressValue = duration > 0 ? currentPosition / duration : 0;

  if (!currentTrack) {
    return (
      <View style={styles.container}>
        <LinearGradient
          colors={['#0f0f23', '#1a1a2e', '#16213e']}
          style={StyleSheet.absoluteFill}
        />
        <SafeAreaView style={styles.safeArea}>
          <View style={styles.emptyState}>
            <Text style={styles.emptyText}>No track selected</Text>
            <TouchableOpacity 
              style={styles.backButton}
              onPress={() => router.back()}
            >
              <Text style={styles.backButtonText}>Go Back</Text>
            </TouchableOpacity>
          </View>
        </SafeAreaView>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      
      {/* Background with blur effect */}
      <Image 
        source={{ uri: currentTrack.artwork || 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=800' }}
        style={styles.backgroundImage}
        blurRadius={80}
      />
      
      <LinearGradient
        colors={['rgba(15, 15, 35, 0.4)', 'rgba(26, 26, 46, 0.8)', 'rgba(15, 15, 35, 0.95)']}
        style={StyleSheet.absoluteFill}
      />

      <SafeAreaView style={styles.safeArea}>
        {/* Header */}
        <View style={styles.header}>
          <TouchableOpacity 
            style={styles.headerButton}
            onPress={() => router.back()}
          >
            <ChevronDown size={width * 0.07} color="#ffffff" strokeWidth={2} />
          </TouchableOpacity>
          
          <View style={styles.headerCenter}>
            <Text style={styles.headerTitle}>Now Playing</Text>
            <Text style={styles.headerSubtitle}>My Player</Text>
          </View>
          
          <TouchableOpacity style={styles.headerButton}>
            <MoreHorizontal size={width * 0.07} color="#ffffff" strokeWidth={2} />
          </TouchableOpacity>
        </View>

        {/* Main Content */}
        <View style={styles.content}>
          {/* Artwork */}
          <View style={styles.artworkContainer}>
            <Animated.View 
              style={[
                styles.artworkWrapper,
                {
                  transform: [
                    { scale: artworkScale },
                    { rotate: rotateInterpolate }
                  ]
                }
              ]}
            >
              <View style={styles.artworkShadow}>
                <Image 
                  source={{ uri: currentTrack.artwork || 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=600' }}
                  style={styles.artwork}
                />
              </View>
              
              {/* Vinyl effect */}
              <View style={styles.vinylCenter}>
                <LinearGradient
                  colors={['rgba(0, 0, 0, 0.8)', 'rgba(0, 0, 0, 0.9)']}
                  style={styles.vinylCenterGradient}
                >
                  <View style={styles.vinylHole} />
                </LinearGradient>
              </View>
            </Animated.View>
            
            {/* Reflection effect */}
            <LinearGradient
              colors={['rgba(255, 255, 255, 0.1)', 'transparent']}
              style={styles.artworkReflection}
            />
          </View>

          {/* Track Info */}
          <View style={styles.trackInfo}>
            <Text style={styles.trackTitle} numberOfLines={2}>
              {currentTrack.title}
            </Text>
            <Text style={styles.trackArtist} numberOfLines={1}>
              {currentTrack.artist}
            </Text>
            
            {/* Action buttons */}
            <View style={styles.actionButtons}>
              <TouchableOpacity 
                style={styles.actionButton}
                onPress={() => setIsLiked(!isLiked)}
              >
                <Heart 
                  size={width * 0.06} 
                  color={isLiked ? "#f093fb" : "#ffffff"} 
                  fill={isLiked ? "#f093fb" : "transparent"}
                  strokeWidth={2}
                />
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.actionButton}>
                <MoreHorizontal size={width * 0.06} color="#ffffff" strokeWidth={2} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Progress */}
          <View style={styles.progressContainer}>
            <Slider
              style={styles.progressSlider}
              minimumValue={0}
              maximumValue={1}
              value={progressValue}
              onSlidingStart={handleSeekStart}
              onValueChange={handleSeekChange}
              onSlidingComplete={handleSeekComplete}
              minimumTrackTintColor="#667eea"
              maximumTrackTintColor="rgba(255, 255, 255, 0.3)"
              thumbStyle={styles.progressThumb}
            />
            
            <View style={styles.timeContainer}>
              <Text style={styles.timeText}>{formatTime(currentPosition)}</Text>
              <Text style={styles.timeText}>{formatTime(duration)}</Text>
            </View>
          </View>

          {/* Controls */}
          <View style={styles.controls}>
            <TouchableOpacity 
              style={styles.controlButton}
              onPress={() => setIsShuffled(!isShuffled)}
            >
              <Shuffle 
                size={width * 0.06} 
                color={isShuffled ? "#667eea" : "rgba(255, 255, 255, 0.7)"} 
                strokeWidth={2}
              />
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.controlButton}
              onPress={previousTrack}
            >
              <SkipBack size={width * 0.08} color="#ffffff" strokeWidth={2} />
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.playButton}
              onPress={playPause}
            >
              <LinearGradient
                colors={['#667eea', '#764ba2']}
                style={styles.playButtonGradient}
              >
                {isPlaying ? (
                  <Pause size={width * 0.08} color="#ffffff" fill="#ffffff" />
                ) : (
                  <Play size={width * 0.08} color="#ffffff" fill="#ffffff" />
                )}
              </LinearGradient>
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.controlButton}
              onPress={nextTrack}
            >
              <SkipForward size={width * 0.08} color="#ffffff" strokeWidth={2} />
            </TouchableOpacity>
            
            <TouchableOpacity 
              style={styles.controlButton}
              onPress={toggleRepeat}
            >
              <Repeat 
                size={width * 0.06} 
                color={repeatMode > 0 ? "#667eea" : "rgba(255, 255, 255, 0.7)"} 
                strokeWidth={2}
              />
              {repeatMode === 2 && (
                <View style={styles.repeatOneDot}>
                  <Text style={styles.repeatOneText}>1</Text>
                </View>
              )}
            </TouchableOpacity>
          </View>

          {/* Bottom Actions */}
          <View style={styles.bottomActions}>
            <TouchableOpacity style={styles.bottomActionButton}>
              <Volume2 size={width * 0.05} color="rgba(255, 255, 255, 0.7)" strokeWidth={2} />
            </TouchableOpacity>
            
            <TouchableOpacity style={styles.bottomActionButton}>
              <List size={width * 0.05} color="rgba(255, 255, 255, 0.7)" strokeWidth={2} />
            </TouchableOpacity>
          </View>
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f0f23',
  },
  backgroundImage: {
    position: 'absolute',
    width: width,
    height: height,
    resizeMode: 'cover',
  },
  safeArea: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: width * 0.06,
    paddingTop: height * 0.015,
    paddingBottom: height * 0.025,
  },
  headerButton: {
    width: width * 0.11,
    height: width * 0.11,
    borderRadius: width * 0.055,
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerCenter: {
    alignItems: 'center',
  },
  headerTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: width * 0.04,
    color: '#ffffff',
  },
  headerSubtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: width * 0.03,
    color: 'rgba(255, 255, 255, 0.7)',
    marginTop: height * 0.003,
  },
  content: {
    flex: 1,
    paddingHorizontal: width * 0.08,
  },
  artworkContainer: {
    alignItems: 'center',
    marginBottom: height * 0.05,
  },
  artworkWrapper: {
    position: 'relative',
  },
  artworkShadow: {
    shadowColor: '#000000',
    shadowOffset: { width: 0, height: 20 },
    shadowOpacity: 0.6,
    shadowRadius: 40,
    elevation: 20,
  },
  artwork: {
    width: width * 0.75,
    height: width * 0.75,
    borderRadius: width * 0.375,
  },
  vinylCenter: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    width: width * 0.2,
    height: width * 0.2,
    borderRadius: width * 0.1,
    justifyContent: 'center',
    alignItems: 'center',
    transform: [{ translateX: -width * 0.1 }, { translateY: -width * 0.1 }],
  },
  vinylCenterGradient: {
    width: width * 0.2,
    height: width * 0.2,
    borderRadius: width * 0.1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  vinylHole: {
    width: width * 0.06,
    height: width * 0.06,
    borderRadius: width * 0.03,
    backgroundColor: '#0f0f23',
  },
  artworkReflection: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '50%',
    borderRadius: width * 0.375,
  },
  trackInfo: {
    alignItems: 'center',
    marginBottom: height * 0.05,
  },
  trackTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: width * 0.07,
    color: '#ffffff',
    textAlign: 'center',
    marginBottom: height * 0.01,
    lineHeight: width * 0.085,
  },
  trackArtist: {
    fontFamily: 'Inter-Medium',
    fontSize: width * 0.045,
    color: 'rgba(255, 255, 255, 0.8)',
    textAlign: 'center',
    marginBottom: height * 0.03,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: width * 0.08,
  },
  actionButton: {
    width: width * 0.12,
    height: width * 0.12,
    borderRadius: width * 0.06,
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  progressContainer: {
    marginBottom: height * 0.05,
  },
  progressSlider: {
    width: '100%',
    height: height * 0.05,
  },
  progressThumb: {
    width: width * 0.05,
    height: width * 0.05,
    backgroundColor: '#667eea',
    shadowColor: '#667eea',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 4,
    elevation: 4,
  },
  timeContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: width * 0.02,
  },
  timeText: {
    fontFamily: 'Inter-Regular',
    fontSize: width * 0.035,
    color: 'rgba(255, 255, 255, 0.7)',
  },
  controls: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: height * 0.04,
    paddingHorizontal: width * 0.02,
  },
  controlButton: {
    width: width * 0.13,
    height: width * 0.13,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  playButton: {
    width: width * 0.21,
    height: width * 0.21,
    borderRadius: width * 0.105,
    overflow: 'hidden',
    shadowColor: '#667eea',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 20,
    elevation: 12,
  },
  playButtonGradient: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  repeatOneDot: {
    position: 'absolute',
    top: width * 0.02,
    right: width * 0.02,
    width: width * 0.035,
    height: width * 0.035,
    borderRadius: width * 0.0175,
    backgroundColor: '#667eea',
    justifyContent: 'center',
    alignItems: 'center',
  },
  repeatOneText: {
    fontFamily: 'Inter-Bold',
    fontSize: width * 0.02,
    color: '#ffffff',
  },
  bottomActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: width * 0.06,
  },
  bottomActionButton: {
    width: width * 0.12,
    height: width * 0.12,
    borderRadius: width * 0.06,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: width * 0.1,
  },
  emptyText: {
    fontFamily: 'Inter-Regular',
    fontSize: width * 0.045,
    color: '#ffffff',
    marginBottom: height * 0.025,
  },
  backButton: {
    backgroundColor: '#667eea',
    paddingHorizontal: width * 0.05,
    paddingVertical: height * 0.015,
    borderRadius: width * 0.05,
  },
  backButtonText: {
    fontFamily: 'Inter-SemiBold',
    fontSize: width * 0.04,
    color: '#ffffff',
  },
});